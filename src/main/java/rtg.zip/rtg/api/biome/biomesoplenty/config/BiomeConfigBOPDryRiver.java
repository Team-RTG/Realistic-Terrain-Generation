package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPDryRiver extends BiomeConfigBOPBase
{
    public BiomeConfigBOPDryRiver()
    {
        super();
        
        this.biomeSlug = "dryriver";
    }
}
