package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPMoor extends BiomeConfigBOPBase
{
    public BiomeConfigBOPMoor()
    {
        super();
        
        this.biomeSlug = "moor";
    }
}
