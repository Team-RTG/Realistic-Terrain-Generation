package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPMeadow extends BiomeConfigBOPBase
{
    public BiomeConfigBOPMeadow()
    {
        super();
        
        this.biomeSlug = "meadow";
    }
}
