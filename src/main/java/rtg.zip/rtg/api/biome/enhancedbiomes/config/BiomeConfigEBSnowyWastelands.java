package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSnowyWastelands extends BiomeConfigEBBase
{
    public BiomeConfigEBSnowyWastelands()
    {
        super();
        
        this.biomeSlug = "snowywastelands";
    }
}
