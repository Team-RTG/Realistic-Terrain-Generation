package rtg.reference;

public class ModInfo
{
    public static final String MOD_ID = "RTG";
    public static final String MOD_NAME = "Realistic Terrain Generation";
    public static final String MOD_VERSION = "@VERSION@";
    
	public static final String PROXY_COMMON = "rtg.proxy.CommonProxy";
	public static final String PROXY_CLIENT = "rtg.proxy.ClientProxy";
}
