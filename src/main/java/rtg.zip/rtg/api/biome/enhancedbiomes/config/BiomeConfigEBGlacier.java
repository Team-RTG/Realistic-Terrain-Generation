package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBGlacier extends BiomeConfigEBBase
{
    public BiomeConfigEBGlacier()
    {
        super();
        
        this.biomeSlug = "glacier";
    }
}
