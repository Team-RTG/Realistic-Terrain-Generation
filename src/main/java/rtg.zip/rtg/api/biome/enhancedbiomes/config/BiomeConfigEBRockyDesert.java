package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBRockyDesert extends BiomeConfigEBBase
{
    public BiomeConfigEBRockyDesert()
    {
        super();
        
        this.biomeSlug = "rockydesert";
    }
}
