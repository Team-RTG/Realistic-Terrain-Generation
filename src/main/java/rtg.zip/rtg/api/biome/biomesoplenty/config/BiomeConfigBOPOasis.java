package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPOasis extends BiomeConfigBOPBase
{
    public BiomeConfigBOPOasis()
    {
        super();
        
        this.biomeSlug = "oasis";
    }
}
