package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPPrairie extends BiomeConfigBOPBase
{
    public BiomeConfigBOPPrairie()
    {
        super();
        
        this.biomeSlug = "prairie";
    }
}
