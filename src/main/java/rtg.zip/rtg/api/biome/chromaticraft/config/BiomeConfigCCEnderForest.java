package rtg.api.biome.chromaticraft.config;





public class BiomeConfigCCEnderForest extends BiomeConfigCCBase
{
    public BiomeConfigCCEnderForest()
    {
        super();
        
        this.biomeSlug = "enderforest";
    }
}
