package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPFen extends BiomeConfigBOPBase
{
    public BiomeConfigBOPFen()
    {
        super();
        
        this.biomeSlug = "fen";
    }
}
