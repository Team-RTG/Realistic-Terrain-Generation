package rtg.api.biome.highlands.config;


public class BiomeConfigHLOasis extends BiomeConfigHLBase
{
    public BiomeConfigHLOasis()
    {
        super();
        
        this.biomeSlug = "oasis";
    }
}
