package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaRiver extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaRiver()
    {
        super();
        
        this.biomeSlug = "river";
    }
}
