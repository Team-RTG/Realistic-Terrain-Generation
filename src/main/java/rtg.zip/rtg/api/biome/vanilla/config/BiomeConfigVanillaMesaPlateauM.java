package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMesaPlateauM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMesaPlateauM()
    {
        super();
        
        this.biomeSlug = "mesaplateaum";
    }
}
