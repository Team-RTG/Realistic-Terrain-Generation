package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBBorealArchipelago extends BiomeConfigEBBase
{
    public BiomeConfigEBBorealArchipelago()
    {
        super();
        
        this.biomeSlug = "borealarchipelago";
    }
}
