package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaExtremeHillsPlusM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaExtremeHillsPlusM()
    {
        super();
        
        this.biomeSlug = "extremehillsplusm";
    }
}
