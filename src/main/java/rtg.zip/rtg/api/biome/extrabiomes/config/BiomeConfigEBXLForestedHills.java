package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLForestedHills extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLForestedHills()
    {
        super();
        
        this.biomeSlug = "forestedhills";
    }
}
