package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPDeciduousForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPDeciduousForest()
    {
        super();
        
        this.biomeSlug = "deciduousforest";
    }
}
