package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPWasteland extends BiomeConfigBOPBase
{
    public BiomeConfigBOPWasteland()
    {
        super();
        
        this.biomeSlug = "wasteland";
    }
}
