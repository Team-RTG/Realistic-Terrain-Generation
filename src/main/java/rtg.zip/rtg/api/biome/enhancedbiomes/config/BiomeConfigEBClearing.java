package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBClearing extends BiomeConfigEBBase
{
    public BiomeConfigEBClearing()
    {
        super();
        
        this.biomeSlug = "clearing";
    }
}
