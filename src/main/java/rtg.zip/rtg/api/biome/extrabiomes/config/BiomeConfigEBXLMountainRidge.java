package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLMountainRidge extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLMountainRidge()
    {
        super();
        
        this.biomeSlug = "mountainridge";
    }
}
