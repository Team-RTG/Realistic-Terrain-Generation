package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaBirchForestM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaBirchForestM()
    {
        super();
        
        this.biomeSlug = "birchforestm";
    }
}
