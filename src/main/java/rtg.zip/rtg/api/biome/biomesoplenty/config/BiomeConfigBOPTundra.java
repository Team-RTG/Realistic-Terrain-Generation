package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPTundra extends BiomeConfigBOPBase
{
    public BiomeConfigBOPTundra()
    {
        super();
        
        this.biomeSlug = "tundra";
    }
}
