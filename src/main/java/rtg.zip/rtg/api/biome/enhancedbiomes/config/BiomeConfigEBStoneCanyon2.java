package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBStoneCanyon2 extends BiomeConfigEBBase
{
    public BiomeConfigEBStoneCanyon2()
    {
        super();
        
        this.biomeSlug = "stonecanyon2";
    }
}
