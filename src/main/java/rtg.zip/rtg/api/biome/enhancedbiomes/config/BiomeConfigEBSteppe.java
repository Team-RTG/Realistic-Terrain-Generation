package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSteppe extends BiomeConfigEBBase
{
    public BiomeConfigEBSteppe()
    {
        super();
        
        this.biomeSlug = "steppe";
    }
}
