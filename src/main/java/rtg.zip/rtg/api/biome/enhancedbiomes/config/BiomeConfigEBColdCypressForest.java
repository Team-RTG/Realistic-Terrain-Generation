package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBColdCypressForest extends BiomeConfigEBBase
{
    public BiomeConfigEBColdCypressForest()
    {
        super();
        
        this.biomeSlug = "coldcypressforest";
    }
}
