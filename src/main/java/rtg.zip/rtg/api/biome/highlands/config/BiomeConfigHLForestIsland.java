package rtg.api.biome.highlands.config;


public class BiomeConfigHLForestIsland extends BiomeConfigHLBase
{
    public BiomeConfigHLForestIsland()
    {
        super();
        
        this.biomeSlug = "forestisland";
    }
}
