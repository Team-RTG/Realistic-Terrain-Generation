package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaColdTaigaHills extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaColdTaigaHills()
    {
        super();
        
        this.biomeSlug = "coldtaigahills";
    }
}
