package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBPolarDesert extends BiomeConfigEBBase
{
    public BiomeConfigEBPolarDesert()
    {
        super();
        
        this.biomeSlug = "polardesert";
    }
}
