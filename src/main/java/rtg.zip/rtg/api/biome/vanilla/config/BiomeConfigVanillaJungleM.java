package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaJungleM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaJungleM()
    {
        super();
        
        this.biomeSlug = "junglem";
    }
}
