package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBBorealPlateauM extends BiomeConfigEBBase
{
    public BiomeConfigEBBorealPlateauM()
    {
        super();
        
        this.biomeSlug = "borealplateaum";
    }
}
