package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBIceSheet extends BiomeConfigEBBase
{
    public BiomeConfigEBIceSheet()
    {
        super();
        
        this.biomeSlug = "icesheet";
    }
}
