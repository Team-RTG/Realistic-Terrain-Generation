package rtg.api.biome.highlands.config;


public class BiomeConfigHLJungleIsland extends BiomeConfigHLBase
{
    public BiomeConfigHLJungleIsland()
    {
        super();
        
        this.biomeSlug = "jungleisland";
    }
}
