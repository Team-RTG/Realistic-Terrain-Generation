package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLMarsh extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLMarsh()
    {
        super();
        
        this.biomeSlug = "marsh";
    }
}
