package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaSavannaPlateau extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaSavannaPlateau()
    {
        super();
        
        this.biomeSlug = "savannaplateau";
    }
}
