package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSnowyPlateau extends BiomeConfigEBBase
{
    public BiomeConfigEBSnowyPlateau()
    {
        super();
        
        this.biomeSlug = "snowyplateau";
    }
}
