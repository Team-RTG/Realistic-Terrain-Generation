package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBMountainsEdge extends BiomeConfigEBBase
{
    public BiomeConfigEBMountainsEdge()
    {
        super();
        
        this.biomeSlug = "mountainsedge";
    }
}
