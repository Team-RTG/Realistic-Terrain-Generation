package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLTemperateRainforest extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLTemperateRainforest()
    {
        super();
        
        this.biomeSlug = "temperaterainforest";
    }
}
