package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBRainforestValley extends BiomeConfigEBBase
{
    public BiomeConfigEBRainforestValley()
    {
        super();
        
        this.biomeSlug = "rainforestvalley";
    }
}
