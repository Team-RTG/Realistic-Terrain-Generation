package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaJungleEdge extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaJungleEdge()
    {
        super();
        
        this.biomeSlug = "jungleedge";
    }
}
