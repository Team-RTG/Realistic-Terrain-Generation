package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBPineForestArchipelago extends BiomeConfigEBBase
{
    public BiomeConfigEBPineForestArchipelago()
    {
        super();
        
        this.biomeSlug = "pineforestarchipelago";
    }
}
