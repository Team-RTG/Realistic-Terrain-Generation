package rtg.api.biome.atg.config;


public class BiomeConfigATGWoodland extends BiomeConfigATGBase
{
    public BiomeConfigATGWoodland()
    {
        super();
        
        this.biomeSlug = "woodland";
    }
}
