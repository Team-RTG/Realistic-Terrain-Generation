package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBBlossomHills extends BiomeConfigEBBase
{
    public BiomeConfigEBBlossomHills()
    {
        super();
        
        this.biomeSlug = "blossomhills";
    }
}
