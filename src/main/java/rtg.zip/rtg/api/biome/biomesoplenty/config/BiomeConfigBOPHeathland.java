package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPHeathland extends BiomeConfigBOPBase
{
    public BiomeConfigBOPHeathland()
    {
        super();
        
        this.biomeSlug = "heathland";
    }
}
