package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPGlacier extends BiomeConfigBOPBase
{
    public BiomeConfigBOPGlacier()
    {
        super();
        
        this.biomeSlug = "glacier";
    }
}
