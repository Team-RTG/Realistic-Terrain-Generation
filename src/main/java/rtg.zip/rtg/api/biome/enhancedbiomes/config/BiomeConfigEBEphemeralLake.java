package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBEphemeralLake extends BiomeConfigEBBase
{
    public BiomeConfigEBEphemeralLake()
    {
        super();
        
        this.biomeSlug = "ephemerallake";
    }
}
