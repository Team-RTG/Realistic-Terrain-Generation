package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBBorealPlateau extends BiomeConfigEBBase
{
    public BiomeConfigEBBorealPlateau()
    {
        super();
        
        this.biomeSlug = "borealplateau";
    }
}
