package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBOasis extends BiomeConfigEBBase
{
    public BiomeConfigEBOasis()
    {
        super();
        
        this.biomeSlug = "oasis";
    }
}
