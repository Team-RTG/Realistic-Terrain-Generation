package rtg.api.biome.extrabiomes.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigEBXLBase extends BiomeConfig
{
    public BiomeConfigEBXLBase()
    {
        super();
        
        this.modSlug = "extrabiomes";
    }
}
