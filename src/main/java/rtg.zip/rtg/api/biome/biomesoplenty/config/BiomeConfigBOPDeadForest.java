package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPDeadForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPDeadForest()
    {
        super();
        
        this.biomeSlug = "deadforest";
    }
}
