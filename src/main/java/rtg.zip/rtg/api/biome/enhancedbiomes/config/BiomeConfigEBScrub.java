package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBScrub extends BiomeConfigEBBase
{
    public BiomeConfigEBScrub()
    {
        super();
        
        this.biomeSlug = "scrub";
    }
}
