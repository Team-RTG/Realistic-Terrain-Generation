package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMegaTaigaHills extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMegaTaigaHills()
    {
        super();
        
        this.biomeSlug = "megataigahills";
    }
}
