package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaTaigaM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaTaigaM()
    {
        super();
        
        this.biomeSlug = "taigam";
    }
}
