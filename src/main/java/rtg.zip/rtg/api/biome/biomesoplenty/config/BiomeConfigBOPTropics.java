package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPTropics extends BiomeConfigBOPBase
{
    public BiomeConfigBOPTropics()
    {
        super();
        
        this.biomeSlug = "tropics";
    }
}
