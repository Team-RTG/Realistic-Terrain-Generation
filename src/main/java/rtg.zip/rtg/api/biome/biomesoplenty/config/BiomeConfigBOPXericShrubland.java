package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPXericShrubland extends BiomeConfigBOPBase
{
    public BiomeConfigBOPXericShrubland()
    {
        super();
        
        this.biomeSlug = "xericshrubland";
    }
}
