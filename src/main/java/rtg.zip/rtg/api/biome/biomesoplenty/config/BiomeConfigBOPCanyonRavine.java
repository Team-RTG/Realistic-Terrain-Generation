package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPCanyonRavine extends BiomeConfigBOPBase
{
    public BiomeConfigBOPCanyonRavine()
    {
        super();
        
        this.biomeSlug = "canyonravine";
    }
}
