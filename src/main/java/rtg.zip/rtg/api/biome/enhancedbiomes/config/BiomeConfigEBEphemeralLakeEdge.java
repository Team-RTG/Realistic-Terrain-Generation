package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBEphemeralLakeEdge extends BiomeConfigEBBase
{
    public BiomeConfigEBEphemeralLakeEdge()
    {
        super();
        
        this.biomeSlug = "ephemerallakeedge";
    }
}
