package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPMarsh extends BiomeConfigBOPBase
{
    public BiomeConfigBOPMarsh()
    {
        super();
        
        this.biomeSlug = "marsh";
    }
}
