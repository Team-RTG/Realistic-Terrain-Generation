package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPMapleWoods extends BiomeConfigBOPBase
{
    public BiomeConfigBOPMapleWoods()
    {
        super();
        
        this.biomeSlug = "maplewoods";
    }
}
