package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBWoodlandLake extends BiomeConfigEBBase
{
    public BiomeConfigEBWoodlandLake()
    {
        super();
        
        this.biomeSlug = "woodlandlake";
    }
}
