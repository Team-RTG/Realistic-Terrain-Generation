package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPWoodland extends BiomeConfigBOPBase
{
    public BiomeConfigBOPWoodland()
    {
        super();
        
        this.biomeSlug = "woodland";
    }
}
