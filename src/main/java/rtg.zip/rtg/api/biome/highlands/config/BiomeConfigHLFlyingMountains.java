package rtg.api.biome.highlands.config;


public class BiomeConfigHLFlyingMountains extends BiomeConfigHLBase
{
    public BiomeConfigHLFlyingMountains()
    {
        super();
        
        this.biomeSlug = "flyingmountains";
    }
}
