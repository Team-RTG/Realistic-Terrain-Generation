package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBAspenForest extends BiomeConfigEBBase
{
    public BiomeConfigEBAspenForest()
    {
        super();
        
        this.biomeSlug = "aspenforest";
    }
}
