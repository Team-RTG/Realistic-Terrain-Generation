package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMesaBryce extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMesaBryce()
    {
        super();
        
        this.biomeSlug = "mesabryce";
    }
}
