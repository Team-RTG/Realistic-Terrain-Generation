package rtg.api.biome.highlands.config;


public class BiomeConfigHLWoodsMountains extends BiomeConfigHLBase
{
    public BiomeConfigHLWoodsMountains()
    {
        super();
        
        this.biomeSlug = "woodsmountains";
    }
}
