package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBAlpineMountainsEdge extends BiomeConfigEBBase
{
    public BiomeConfigEBAlpineMountainsEdge()
    {
        super();
        
        this.biomeSlug = "alpinemountainsedge";
    }
}
