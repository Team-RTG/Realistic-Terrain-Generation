package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPDenseForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPDenseForest()
    {
        super();
        
        this.biomeSlug = "denseforest";
    }
}
