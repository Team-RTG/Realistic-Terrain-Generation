package rtg.api.biome.highlands.config;


public class BiomeConfigHLAlps extends BiomeConfigHLBase
{
    public BiomeConfigHLAlps()
    {
        super();
        
        this.biomeSlug = "alps";
    }
}
