package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLSavanna extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLSavanna()
    {
        super();
        
        this.biomeSlug = "savanna";
    }
}
