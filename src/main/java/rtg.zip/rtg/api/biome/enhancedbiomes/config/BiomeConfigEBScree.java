package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBScree extends BiomeConfigEBBase
{
    public BiomeConfigEBScree()
    {
        super();
        
        this.biomeSlug = "scree";
    }
}
