package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLWoodlands extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLWoodlands()
    {
        super();
        
        this.biomeSlug = "woodlands";
    }
}
