package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMesa extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMesa()
    {
        super();
        
        this.biomeSlug = "mesa";
    }
}
