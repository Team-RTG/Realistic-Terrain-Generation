package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPFrostForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPFrostForest()
    {
        super();
        
        this.biomeSlug = "frostforest";
    }
}
