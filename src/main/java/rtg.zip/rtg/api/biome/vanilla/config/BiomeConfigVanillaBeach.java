package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaBeach extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaBeach()
    {
        super();
        
        this.biomeSlug = "beach";
    }
}
