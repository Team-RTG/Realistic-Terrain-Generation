package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBPlateau extends BiomeConfigEBBase
{
    public BiomeConfigEBPlateau()
    {
        super();
        
        this.biomeSlug = "plateau";
    }
}
