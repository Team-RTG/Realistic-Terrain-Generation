package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLWasteland extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLWasteland()
    {
        super();
        
        this.biomeSlug = "wasteland";
    }
}
