package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPSteppe extends BiomeConfigBOPBase
{
    public BiomeConfigBOPSteppe()
    {
        super();
        
        this.biomeSlug = "steppe";
    }
}
