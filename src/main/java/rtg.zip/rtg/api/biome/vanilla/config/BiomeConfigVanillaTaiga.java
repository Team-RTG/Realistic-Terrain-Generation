package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaTaiga extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaTaiga()
    {
        super();
        
        this.biomeSlug = "taiga";
    }
}
