package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPQuagmire extends BiomeConfigBOPBase
{
    public BiomeConfigBOPQuagmire()
    {
        super();
        
        this.biomeSlug = "quagmire";
    }
}
