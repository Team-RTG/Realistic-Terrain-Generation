package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBBasin extends BiomeConfigEBBase
{
    public BiomeConfigEBBasin()
    {
        super();
        
        this.biomeSlug = "basin";
    }
}
