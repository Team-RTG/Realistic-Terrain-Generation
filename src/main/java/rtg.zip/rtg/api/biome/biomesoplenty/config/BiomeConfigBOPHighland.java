package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPHighland extends BiomeConfigBOPBase
{
    public BiomeConfigBOPHighland()
    {
        super();
        
        this.biomeSlug = "highland";
    }
}
