package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaIcePlainsSpikes extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaIcePlainsSpikes()
    {
        super();
        
        this.biomeSlug = "iceplainsspikes";
    }
}
