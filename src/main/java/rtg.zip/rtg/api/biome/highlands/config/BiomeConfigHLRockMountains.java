package rtg.api.biome.highlands.config;


public class BiomeConfigHLRockMountains extends BiomeConfigHLBase
{
    public BiomeConfigHLRockMountains()
    {
        super();
        
        this.biomeSlug = "rockmountains";
    }
}
