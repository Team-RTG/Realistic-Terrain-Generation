package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBBadlands extends BiomeConfigEBBase
{
    public BiomeConfigEBBadlands()
    {
        super();
        
        this.biomeSlug = "badlands";
    }
}
