package rtg.api.biome.atg.config;


public class BiomeConfigATGTropicalShrubland extends BiomeConfigATGBase
{
    public BiomeConfigATGTropicalShrubland()
    {
        super();
        
        this.biomeSlug = "tropicalshrubland";
    }
}
