package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBWoodlandHills extends BiomeConfigEBBase
{
    public BiomeConfigEBWoodlandHills()
    {
        super();
        
        this.biomeSlug = "woodlandhills";
    }
}
