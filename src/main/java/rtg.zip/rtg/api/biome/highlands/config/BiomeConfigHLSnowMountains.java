package rtg.api.biome.highlands.config;


public class BiomeConfigHLSnowMountains extends BiomeConfigHLBase
{
    public BiomeConfigHLSnowMountains()
    {
        super();
        
        this.biomeSlug = "snowmountains";
    }
}
