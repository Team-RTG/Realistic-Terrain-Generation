package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBColdBorealForest extends BiomeConfigEBBase
{
    public BiomeConfigEBColdBorealForest()
    {
        super();
        
        this.biomeSlug = "coldborealforest";
    }
}
