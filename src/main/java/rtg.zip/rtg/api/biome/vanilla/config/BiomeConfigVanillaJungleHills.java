package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaJungleHills extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaJungleHills()
    {
        super();
        
        this.biomeSlug = "junglehills";
    }
}
