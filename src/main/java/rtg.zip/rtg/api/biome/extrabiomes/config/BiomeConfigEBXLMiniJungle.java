package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLMiniJungle extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLMiniJungle()
    {
        super();
        
        this.biomeSlug = "minijungle";
    }
}
