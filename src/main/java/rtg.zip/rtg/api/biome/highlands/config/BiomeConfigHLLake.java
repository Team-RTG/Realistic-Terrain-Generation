package rtg.api.biome.highlands.config;


public class BiomeConfigHLLake extends BiomeConfigHLBase
{
    public BiomeConfigHLLake()
    {
        super();
        
        this.biomeSlug = "lake";
    }
}
