package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBForestedMountains extends BiomeConfigEBBase
{
    public BiomeConfigEBForestedMountains()
    {
        super();
        
        this.biomeSlug = "forestedmountains";
    }
}
