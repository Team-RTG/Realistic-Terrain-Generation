package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPGrassland extends BiomeConfigBOPBase
{
    public BiomeConfigBOPGrassland()
    {
        super();
        
        this.biomeSlug = "grassland";
    }
}
