package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBLake extends BiomeConfigEBBase
{
    public BiomeConfigEBLake()
    {
        super();
        
        this.biomeSlug = "lake";
    }
}
