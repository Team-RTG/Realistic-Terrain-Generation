package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBColdPineForest extends BiomeConfigEBBase
{
    public BiomeConfigEBColdPineForest()
    {
        super();
        
        this.biomeSlug = "coldpineforest";
    }
}
