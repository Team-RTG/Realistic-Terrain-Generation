package rtg.api.biome.highlands.config;


public class BiomeConfigHLGlacier extends BiomeConfigHLBase
{
    public BiomeConfigHLGlacier()
    {
        super();
        
        this.biomeSlug = "glacier";
    }
}
