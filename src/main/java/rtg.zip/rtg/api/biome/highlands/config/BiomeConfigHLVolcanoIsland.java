package rtg.api.biome.highlands.config;


public class BiomeConfigHLVolcanoIsland extends BiomeConfigHLBase
{
    public BiomeConfigHLVolcanoIsland()
    {
        super();
        
        this.biomeSlug = "volcanoisland";
    }
}
