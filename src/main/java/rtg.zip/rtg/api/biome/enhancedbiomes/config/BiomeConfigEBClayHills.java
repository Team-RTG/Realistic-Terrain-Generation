package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBClayHills extends BiomeConfigEBBase
{
    public BiomeConfigEBClayHills()
    {
        super();
        
        this.biomeSlug = "clayhills";
    }
}
