package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaExtremeHills extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaExtremeHills()
    {
        super();
        
        this.biomeSlug = "extremehills";
    }
}
