package rtg.api.biome.highlands.config;


public class BiomeConfigHLSteppe extends BiomeConfigHLBase
{
    public BiomeConfigHLSteppe()
    {
        super();
        
        this.biomeSlug = "steppe";
    }
}
