package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBBlossomWoods extends BiomeConfigEBBase
{
    public BiomeConfigEBBlossomWoods()
    {
        super();
        
        this.biomeSlug = "blossomwoods";
    }
}
