package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBShield extends BiomeConfigEBBase
{
    public BiomeConfigEBShield()
    {
        super();
        
        this.biomeSlug = "shield";
    }
}
