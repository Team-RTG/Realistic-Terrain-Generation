package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBTundra extends BiomeConfigEBBase
{
    public BiomeConfigEBTundra()
    {
        super();
        
        this.biomeSlug = "tundra";
    }
}
