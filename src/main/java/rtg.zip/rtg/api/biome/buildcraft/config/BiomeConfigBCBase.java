package rtg.api.biome.buildcraft.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigBCBase extends BiomeConfig
{
    public BiomeConfigBCBase()
    {
        super();
        
        this.modSlug = "buildcraft";
    }
}
