package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBWoodlandLakeEdge extends BiomeConfigEBBase
{
    public BiomeConfigEBWoodlandLakeEdge()
    {
        super();
        
        this.biomeSlug = "woodlandlakeedge";
    }
}
