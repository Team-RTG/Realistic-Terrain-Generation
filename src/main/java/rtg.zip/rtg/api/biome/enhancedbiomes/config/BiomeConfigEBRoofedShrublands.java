package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBRoofedShrublands extends BiomeConfigEBBase
{
    public BiomeConfigEBRoofedShrublands()
    {
        super();
        
        this.biomeSlug = "roofedshrublands";
    }
}
