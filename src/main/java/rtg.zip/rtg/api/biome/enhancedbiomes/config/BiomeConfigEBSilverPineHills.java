package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSilverPineHills extends BiomeConfigEBBase
{
    public BiomeConfigEBSilverPineHills()
    {
        super();
        
        this.biomeSlug = "silverpinehills";
    }
}
