package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSandstoneRangesM extends BiomeConfigEBBase
{
    public BiomeConfigEBSandstoneRangesM()
    {
        super();
        
        this.biomeSlug = "sandstonerangesm";
    }
}
