package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSahara extends BiomeConfigEBBase
{
    public BiomeConfigEBSahara()
    {
        super();
        
        this.biomeSlug = "sahara";
    }
}
