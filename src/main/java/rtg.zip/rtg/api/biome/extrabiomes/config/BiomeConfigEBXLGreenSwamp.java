package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLGreenSwamp extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLGreenSwamp()
    {
        super();
        
        this.biomeSlug = "greenswamp";
    }
}
