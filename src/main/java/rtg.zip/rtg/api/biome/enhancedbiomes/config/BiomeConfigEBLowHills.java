package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBLowHills extends BiomeConfigEBBase
{
    public BiomeConfigEBLowHills()
    {
        super();
        
        this.biomeSlug = "lowhills";
    }
}
