package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBForestedValley extends BiomeConfigEBBase
{
    public BiomeConfigEBForestedValley()
    {
        super();
        
        this.biomeSlug = "forestedvalley";
    }
}
