package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaJungleEdgeM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaJungleEdgeM()
    {
        super();
        
        this.biomeSlug = "jungleedgem";
    }
}
