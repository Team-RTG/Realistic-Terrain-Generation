package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLGreenHills extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLGreenHills()
    {
        super();
        
        this.biomeSlug = "greenhills";
    }
}
