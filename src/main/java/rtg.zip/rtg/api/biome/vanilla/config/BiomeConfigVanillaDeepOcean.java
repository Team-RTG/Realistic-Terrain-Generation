package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaDeepOcean extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaDeepOcean()
    {
        super();
        
        this.biomeSlug = "deepocean";
    }
}
