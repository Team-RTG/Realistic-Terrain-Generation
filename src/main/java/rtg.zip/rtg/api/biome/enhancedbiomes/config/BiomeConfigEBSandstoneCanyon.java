package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSandstoneCanyon extends BiomeConfigEBBase
{
    public BiomeConfigEBSandstoneCanyon()
    {
        super();
        
        this.biomeSlug = "sandstonecanyon";
    }
}
