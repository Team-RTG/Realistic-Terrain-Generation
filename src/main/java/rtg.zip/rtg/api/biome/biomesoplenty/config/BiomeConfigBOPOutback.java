package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPOutback extends BiomeConfigBOPBase
{
    public BiomeConfigBOPOutback()
    {
        super();
        
        this.biomeSlug = "outback";
    }
}
