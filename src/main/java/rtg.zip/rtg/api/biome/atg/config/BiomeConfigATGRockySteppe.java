package rtg.api.biome.atg.config;


public class BiomeConfigATGRockySteppe extends BiomeConfigATGBase
{
    public BiomeConfigATGRockySteppe()
    {
        super();
        
        this.biomeSlug = "rockysteppe";
    }
}
