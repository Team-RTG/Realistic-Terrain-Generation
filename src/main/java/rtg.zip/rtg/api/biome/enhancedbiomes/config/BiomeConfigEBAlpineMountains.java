package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBAlpineMountains extends BiomeConfigEBBase
{
    public BiomeConfigEBAlpineMountains()
    {
        super();
        
        this.biomeSlug = "alpinemountains";
    }
}
