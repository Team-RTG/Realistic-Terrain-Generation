package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPBorealForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPBorealForest()
    {
        super();
        
        this.biomeSlug = "borealforest";
    }
}
