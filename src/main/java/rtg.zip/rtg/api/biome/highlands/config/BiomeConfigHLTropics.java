package rtg.api.biome.highlands.config;


public class BiomeConfigHLTropics extends BiomeConfigHLBase
{
    public BiomeConfigHLTropics()
    {
        super();
        
        this.biomeSlug = "tropics";
    }
}
