package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaTaigaHills extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaTaigaHills()
    {
        super();
        
        this.biomeSlug = "taigahills";
    }
}
