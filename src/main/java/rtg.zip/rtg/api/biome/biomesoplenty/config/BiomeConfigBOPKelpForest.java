package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPKelpForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPKelpForest()
    {
        super();
        
        this.biomeSlug = "kelpforest";
    }
}
