package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaExtremeHillsM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaExtremeHillsM()
    {
        super();
        
        this.biomeSlug = "extremehillsm";
    }
}
