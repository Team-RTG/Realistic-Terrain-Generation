package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPJadeCliffs extends BiomeConfigBOPBase
{
    public BiomeConfigBOPJadeCliffs()
    {
        super();
        
        this.biomeSlug = "jadecliffs";
    }
}
