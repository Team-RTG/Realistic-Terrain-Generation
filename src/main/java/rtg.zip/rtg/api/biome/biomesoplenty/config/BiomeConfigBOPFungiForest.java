package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPFungiForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPFungiForest()
    {
        super();
        
        this.biomeSlug = "fungiforest";
    }
}
