package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaBirchForest extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaBirchForest()
    {
        super();
        
        this.biomeSlug = "birchforest";
    }
}
