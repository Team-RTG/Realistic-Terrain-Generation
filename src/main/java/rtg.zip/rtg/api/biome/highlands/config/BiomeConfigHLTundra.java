package rtg.api.biome.highlands.config;


public class BiomeConfigHLTundra extends BiomeConfigHLBase
{
    public BiomeConfigHLTundra()
    {
        super();
        
        this.biomeSlug = "tundra";
    }
}
