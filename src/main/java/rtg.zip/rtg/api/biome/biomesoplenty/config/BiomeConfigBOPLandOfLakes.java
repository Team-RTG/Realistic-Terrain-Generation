package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPLandOfLakes extends BiomeConfigBOPBase
{
    public BiomeConfigBOPLandOfLakes()
    {
        super();
        
        this.biomeSlug = "landoflakes";
    }
}
