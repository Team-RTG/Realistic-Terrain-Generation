package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMushroomIslandShore extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMushroomIslandShore()
    {
        super();
        
        this.biomeSlug = "mushroomislandshore";
    }
}
