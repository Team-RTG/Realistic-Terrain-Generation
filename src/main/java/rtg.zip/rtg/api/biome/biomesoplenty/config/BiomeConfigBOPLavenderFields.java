package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPLavenderFields extends BiomeConfigBOPBase
{
    public BiomeConfigBOPLavenderFields()
    {
        super();
        
        this.biomeSlug = "lavenderfields";
    }
}
