package rtg.api.biome.chromaticraft.config;





public class BiomeConfigCCRainbowForest extends BiomeConfigCCBase
{
    public BiomeConfigCCRainbowForest()
    {
        super();
        
        this.biomeSlug = "rainbowforest";
    }
}
