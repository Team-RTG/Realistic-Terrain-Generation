package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaIcePlains extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaIcePlains()
    {
        super();
        
        this.biomeSlug = "iceplains";
    }
}
