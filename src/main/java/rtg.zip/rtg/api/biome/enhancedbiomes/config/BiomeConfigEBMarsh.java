package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBMarsh extends BiomeConfigEBBase
{
    public BiomeConfigEBMarsh()
    {
        super();
        
        this.biomeSlug = "marsh";
    }
}
