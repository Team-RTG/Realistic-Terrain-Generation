package rtg.api.biome.atg.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigATGBase extends BiomeConfig
{
    public BiomeConfigATGBase()
    {
        super();
        
        this.modSlug = "atg";
    }
}
