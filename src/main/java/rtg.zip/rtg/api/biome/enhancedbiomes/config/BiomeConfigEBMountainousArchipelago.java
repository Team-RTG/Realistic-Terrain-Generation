package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBMountainousArchipelago extends BiomeConfigEBBase
{
    public BiomeConfigEBMountainousArchipelago()
    {
        super();
        
        this.biomeSlug = "mountainousarchipelago";
    }
}
