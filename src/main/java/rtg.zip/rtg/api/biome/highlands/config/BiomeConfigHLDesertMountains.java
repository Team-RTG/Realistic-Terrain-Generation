package rtg.api.biome.highlands.config;


public class BiomeConfigHLDesertMountains extends BiomeConfigHLBase
{
    public BiomeConfigHLDesertMountains()
    {
        super();
        
        this.biomeSlug = "desertmountains";
    }
}
