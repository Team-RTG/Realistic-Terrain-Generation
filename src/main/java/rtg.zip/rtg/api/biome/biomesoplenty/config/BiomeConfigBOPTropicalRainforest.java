package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPTropicalRainforest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPTropicalRainforest()
    {
        super();
        
        this.biomeSlug = "tropicalrainforest";
    }
}
