package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaSunflowerPlains extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaSunflowerPlains()
    {
        super();
        
        this.biomeSlug = "sunflowerplains";
    }
}
