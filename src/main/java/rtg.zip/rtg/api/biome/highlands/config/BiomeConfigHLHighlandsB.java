package rtg.api.biome.highlands.config;


public class BiomeConfigHLHighlandsB extends BiomeConfigHLBase
{
    public BiomeConfigHLHighlandsB()
    {
        super();
        
        this.biomeSlug = "highlandsb";
    }
}
