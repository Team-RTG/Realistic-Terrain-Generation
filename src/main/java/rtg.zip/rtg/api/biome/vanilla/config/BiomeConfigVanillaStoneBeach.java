package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaStoneBeach extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaStoneBeach()
    {
        super();
        
        this.biomeSlug = "stonebeach";
    }
}
