package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaRoofedForestM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaRoofedForestM()
    {
        super();
        
        this.biomeSlug = "roofedforestm";
    }
}
