package rtg.api.biome.buildcraft.config;




public class BiomeConfigBCOceanOilField extends BiomeConfigBCBase
{
    public BiomeConfigBCOceanOilField()
    {
        super();
        
        this.biomeSlug = "oceanoilfield";
    }
}
