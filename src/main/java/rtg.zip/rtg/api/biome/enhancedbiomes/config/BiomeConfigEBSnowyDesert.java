package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSnowyDesert extends BiomeConfigEBBase
{
    public BiomeConfigEBSnowyDesert()
    {
        super();
        
        this.biomeSlug = "snowydesert";
    }
}
