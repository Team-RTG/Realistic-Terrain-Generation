package rtg.api.biome.highlands.config;


public class BiomeConfigHLWoodlands extends BiomeConfigHLBase
{
    public BiomeConfigHLWoodlands()
    {
        super();
        
        this.biomeSlug = "woodlands";
    }
}
