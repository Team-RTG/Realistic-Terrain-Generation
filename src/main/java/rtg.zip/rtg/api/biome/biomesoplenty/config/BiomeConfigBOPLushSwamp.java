package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPLushSwamp extends BiomeConfigBOPBase
{
    public BiomeConfigBOPLushSwamp()
    {
        super();
        
        this.biomeSlug = "lushswamp";
    }
}
