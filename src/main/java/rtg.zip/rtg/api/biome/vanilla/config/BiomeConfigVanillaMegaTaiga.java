package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMegaTaiga extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMegaTaiga()
    {
        super();
        
        this.biomeSlug = "megataiga";
    }
}
