package rtg.api.biome.highlands.config;


public class BiomeConfigHLBog extends BiomeConfigHLBase
{
    public BiomeConfigHLBog()
    {
        super();
        
        this.biomeSlug = "bog";
    }
}
