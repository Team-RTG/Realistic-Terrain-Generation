package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBFens extends BiomeConfigEBBase
{
    public BiomeConfigEBFens()
    {
        super();
        
        this.biomeSlug = "fens";
    }
}
