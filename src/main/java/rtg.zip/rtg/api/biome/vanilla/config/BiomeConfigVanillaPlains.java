package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaPlains extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaPlains()
    {
        super();
        
        this.biomeSlug = "plains";
    }
}
