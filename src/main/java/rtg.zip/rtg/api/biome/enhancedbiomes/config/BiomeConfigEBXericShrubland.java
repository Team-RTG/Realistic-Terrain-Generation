package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBXericShrubland extends BiomeConfigEBBase
{
    public BiomeConfigEBXericShrubland()
    {
        super();
        
        this.biomeSlug = "xericshrubland";
    }
}
