package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPLushRiver extends BiomeConfigBOPBase
{
    public BiomeConfigBOPLushRiver()
    {
        super();
        
        this.biomeSlug = "lushriver";
    }
}
