package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPCanyon extends BiomeConfigBOPBase
{
    public BiomeConfigBOPCanyon()
    {
        super();
        
        this.biomeSlug = "canyon";
    }
}
