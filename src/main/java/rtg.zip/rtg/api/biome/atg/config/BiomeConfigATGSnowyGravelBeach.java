package rtg.api.biome.atg.config;


public class BiomeConfigATGSnowyGravelBeach extends BiomeConfigATGBase
{
    public BiomeConfigATGSnowyGravelBeach()
    {
        super();
        
        this.biomeSlug = "snowygravelbeach";
    }
}
