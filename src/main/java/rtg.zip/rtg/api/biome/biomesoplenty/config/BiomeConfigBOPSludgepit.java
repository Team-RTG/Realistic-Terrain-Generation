package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPSludgepit extends BiomeConfigBOPBase
{
    public BiomeConfigBOPSludgepit()
    {
        super();
        
        this.biomeSlug = "sludgepit";
    }
}
