package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLRainforest extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLRainforest()
    {
        super();
        
        this.biomeSlug = "rainforest";
    }
}
