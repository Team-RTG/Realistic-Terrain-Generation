package rtg.api.biome.arsmagica.config;


public class BiomeConfigAMWitchwoodForest extends BiomeConfigAMBase
{
    public BiomeConfigAMWitchwoodForest()
    {
        super();
        
        this.biomeSlug = "witchwoodforest";
    }
}
