package rtg.api.biome.thaumcraft.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigTCBase extends BiomeConfig
{
    public BiomeConfigTCBase()
    {
        super();
        
        this.modSlug = "thaumcraft";
    }
}
