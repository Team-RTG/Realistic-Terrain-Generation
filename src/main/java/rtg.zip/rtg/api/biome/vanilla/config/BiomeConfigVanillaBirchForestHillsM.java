package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaBirchForestHillsM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaBirchForestHillsM()
    {
        super();
        
        this.biomeSlug = "birchforesthillsm";
    }
}
