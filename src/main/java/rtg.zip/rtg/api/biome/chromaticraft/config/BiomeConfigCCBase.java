package rtg.api.biome.chromaticraft.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigCCBase extends BiomeConfig
{
    public BiomeConfigCCBase()
    {
        super();
        
        this.modSlug = "chromaticraft";
    }
}
