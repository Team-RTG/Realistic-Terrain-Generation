package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMesaPlateauF extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMesaPlateauF()
    {
        super();
        
        this.biomeSlug = "mesaplateauf";
    }
}
