package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaColdBeach extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaColdBeach()
    {
        super();
        
        this.biomeSlug = "coldbeach";
    }
}
