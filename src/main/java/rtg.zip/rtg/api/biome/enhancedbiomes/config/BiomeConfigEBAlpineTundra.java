package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBAlpineTundra extends BiomeConfigEBBase
{
    public BiomeConfigEBAlpineTundra()
    {
        super();
        
        this.biomeSlug = "alpinetundra";
    }
}
