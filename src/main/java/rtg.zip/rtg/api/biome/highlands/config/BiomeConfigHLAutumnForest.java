package rtg.api.biome.highlands.config;


public class BiomeConfigHLAutumnForest extends BiomeConfigHLBase
{
    public BiomeConfigHLAutumnForest()
    {
        super();
        
        this.biomeSlug = "autumnforest";
    }
}
