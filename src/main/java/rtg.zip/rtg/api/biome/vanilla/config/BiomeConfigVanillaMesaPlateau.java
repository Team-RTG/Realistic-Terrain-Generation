package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMesaPlateau extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMesaPlateau()
    {
        super();
        
        this.biomeSlug = "mesaplateau";
    }
}
