package rtg.api.biome.highlands.config;


public class BiomeConfigHLCliffs extends BiomeConfigHLBase
{
    public BiomeConfigHLCliffs()
    {
        super();
        
        this.biomeSlug = "cliffs";
    }
}
