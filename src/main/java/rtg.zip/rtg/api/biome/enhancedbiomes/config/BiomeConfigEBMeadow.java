package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBMeadow extends BiomeConfigEBBase
{
    public BiomeConfigEBMeadow()
    {
        super();
        
        this.biomeSlug = "meadow";
    }
}
