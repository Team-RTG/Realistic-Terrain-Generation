package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBWoodlandField extends BiomeConfigEBBase
{
    public BiomeConfigEBWoodlandField()
    {
        super();
        
        this.biomeSlug = "woodlandfield";
    }
}
