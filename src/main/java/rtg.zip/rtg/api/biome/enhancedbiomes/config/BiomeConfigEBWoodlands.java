package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBWoodlands extends BiomeConfigEBBase
{
    public BiomeConfigEBWoodlands()
    {
        super();
        
        this.biomeSlug = "woodlands";
    }
}
