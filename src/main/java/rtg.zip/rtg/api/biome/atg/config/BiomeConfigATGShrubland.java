package rtg.api.biome.atg.config;


public class BiomeConfigATGShrubland extends BiomeConfigATGBase
{
    public BiomeConfigATGShrubland()
    {
        super();
        
        this.biomeSlug = "shrubland";
    }
}
