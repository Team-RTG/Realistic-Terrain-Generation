package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBXericSavanna extends BiomeConfigEBBase
{
    public BiomeConfigEBXericSavanna()
    {
        super();
        
        this.biomeSlug = "xericsavanna";
    }
}
