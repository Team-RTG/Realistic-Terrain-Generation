package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaExtremeHillsPlus extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaExtremeHillsPlus()
    {
        super();
        
        this.biomeSlug = "extremehillsplus";
    }
}
