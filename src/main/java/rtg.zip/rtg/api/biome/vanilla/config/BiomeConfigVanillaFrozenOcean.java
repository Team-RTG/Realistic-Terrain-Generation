package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaFrozenOcean extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaFrozenOcean()
    {
        super();
        
        this.biomeSlug = "frozenocean";
    }
}
