package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLAutumnWoods extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLAutumnWoods()
    {
        super();
        
        this.biomeSlug = "autumnwoods";
    }
}
