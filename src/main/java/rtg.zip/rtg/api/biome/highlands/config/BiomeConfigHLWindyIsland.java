package rtg.api.biome.highlands.config;


public class BiomeConfigHLWindyIsland extends BiomeConfigHLBase
{
    public BiomeConfigHLWindyIsland()
    {
        super();
        
        this.biomeSlug = "windyisland";
    }
}
