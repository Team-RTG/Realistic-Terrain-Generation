package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBVolcanoM extends BiomeConfigEBBase
{
    public BiomeConfigEBVolcanoM()
    {
        super();
        
        this.biomeSlug = "volcanom";
    }
}
