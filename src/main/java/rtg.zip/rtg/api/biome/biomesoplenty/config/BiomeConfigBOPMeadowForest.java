package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPMeadowForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPMeadowForest()
    {
        super();
        
        this.biomeSlug = "meadowforest";
    }
}
