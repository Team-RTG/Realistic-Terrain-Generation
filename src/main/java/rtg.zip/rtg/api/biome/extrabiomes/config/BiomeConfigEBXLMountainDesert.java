package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLMountainDesert extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLMountainDesert()
    {
        super();
        
        this.biomeSlug = "mountaindesert";
    }
}
