package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPDeadSwamp extends BiomeConfigBOPBase
{
    public BiomeConfigBOPDeadSwamp()
    {
        super();
        
        this.biomeSlug = "deadswamp";
    }
}
