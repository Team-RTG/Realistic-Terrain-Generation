package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLMeadow extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLMeadow()
    {
        super();
        
        this.biomeSlug = "meadow";
    }
}
