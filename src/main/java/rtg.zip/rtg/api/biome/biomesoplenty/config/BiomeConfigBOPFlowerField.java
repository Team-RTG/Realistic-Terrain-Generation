package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPFlowerField extends BiomeConfigBOPBase
{
    public BiomeConfigBOPFlowerField()
    {
        super();
        
        this.biomeSlug = "flowerfield";
    }
}
