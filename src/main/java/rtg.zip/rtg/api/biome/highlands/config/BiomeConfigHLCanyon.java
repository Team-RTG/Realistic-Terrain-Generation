package rtg.api.biome.highlands.config;


public class BiomeConfigHLCanyon extends BiomeConfigHLBase
{
    public BiomeConfigHLCanyon()
    {
        super();
        
        this.biomeSlug = "canyon";
    }
}
