package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPEucalyptusForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPEucalyptusForest()
    {
        super();
        
        this.biomeSlug = "eucalyptusforest";
    }
}
