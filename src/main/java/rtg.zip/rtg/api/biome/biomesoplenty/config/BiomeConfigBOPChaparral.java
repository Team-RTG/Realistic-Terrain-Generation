package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPChaparral extends BiomeConfigBOPBase
{
    public BiomeConfigBOPChaparral()
    {
        super();
        
        this.biomeSlug = "chaparral";
    }
}
