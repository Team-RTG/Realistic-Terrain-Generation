package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLPineForest extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLPineForest()
    {
        super();
        
        this.biomeSlug = "pineforest";
    }
}
