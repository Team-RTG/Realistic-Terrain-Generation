package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPRedwoodForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPRedwoodForest()
    {
        super();
        
        this.biomeSlug = "redwoodforest";
    }
}
