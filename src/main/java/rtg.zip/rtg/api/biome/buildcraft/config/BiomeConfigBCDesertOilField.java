package rtg.api.biome.buildcraft.config;




public class BiomeConfigBCDesertOilField extends BiomeConfigBCBase
{
    public BiomeConfigBCDesertOilField()
    {
        super();
        
        this.biomeSlug = "desertoilfield";
    }
}
