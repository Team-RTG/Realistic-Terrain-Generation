package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPSacredSprings extends BiomeConfigBOPBase
{
    public BiomeConfigBOPSacredSprings()
    {
        super();
        
        this.biomeSlug = "sacredsprings";
    }
}
