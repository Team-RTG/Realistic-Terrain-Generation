package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLBirchForest extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLBirchForest()
    {
        super();
        
        this.biomeSlug = "birchforest";
    }
}
