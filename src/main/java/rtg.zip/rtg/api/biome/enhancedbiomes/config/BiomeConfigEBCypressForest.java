package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBCypressForest extends BiomeConfigEBBase
{
    public BiomeConfigEBCypressForest()
    {
        super();
        
        this.biomeSlug = "cypressforest";
    }
}
