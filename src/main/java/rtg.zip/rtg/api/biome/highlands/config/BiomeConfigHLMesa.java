package rtg.api.biome.highlands.config;


public class BiomeConfigHLMesa extends BiomeConfigHLBase
{
    public BiomeConfigHLMesa()
    {
        super();
        
        this.biomeSlug = "mesa";
    }
}
