package rtg.api.biome.highlands.config;


public class BiomeConfigHLBirchHills extends BiomeConfigHLBase
{
    public BiomeConfigHLBirchHills()
    {
        super();
        
        this.biomeSlug = "birchhills";
    }
}
