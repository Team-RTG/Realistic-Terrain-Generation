package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPThicket extends BiomeConfigBOPBase
{
    public BiomeConfigBOPThicket()
    {
        super();
        
        this.biomeSlug = "thicket";
    }
}
