package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBWastelands extends BiomeConfigEBBase
{
    public BiomeConfigEBWastelands()
    {
        super();
        
        this.biomeSlug = "wastelands";
    }
}
