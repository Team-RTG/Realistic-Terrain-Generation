package rtg.api.biome.highlands.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigHLBase extends BiomeConfig
{
    public BiomeConfigHLBase()
    {
        super();
        
        this.modSlug = "highlands";
    }
}
