package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLRedwoodLush extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLRedwoodLush()
    {
        super();
        
        this.biomeSlug = "redwoodlush";
    }
}
