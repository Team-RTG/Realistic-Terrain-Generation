package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaDesertM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaDesertM()
    {
        super();
        
        this.biomeSlug = "desertm";
    }
}
