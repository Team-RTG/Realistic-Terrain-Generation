package rtg.api.biome.highlands.config;


public class BiomeConfigHLDesertIsland extends BiomeConfigHLBase
{
    public BiomeConfigHLDesertIsland()
    {
        super();
        
        this.biomeSlug = "desertisland";
    }
}
