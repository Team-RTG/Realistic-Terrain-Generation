package rtg.api.biome.vanilla.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigVanillaBase extends BiomeConfig
{
    
    public BiomeConfigVanillaBase()
    {
        super();
        
        this.modSlug = "vanilla";
    }
}
