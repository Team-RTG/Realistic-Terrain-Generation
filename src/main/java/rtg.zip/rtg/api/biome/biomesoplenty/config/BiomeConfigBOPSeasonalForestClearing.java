package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPSeasonalForestClearing extends BiomeConfigBOPBase
{
    public BiomeConfigBOPSeasonalForestClearing()
    {
        super();
        
        this.biomeSlug = "seasonalforestclearing";
    }
}
