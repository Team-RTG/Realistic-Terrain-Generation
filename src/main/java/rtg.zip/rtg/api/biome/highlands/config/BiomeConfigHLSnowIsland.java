package rtg.api.biome.highlands.config;


public class BiomeConfigHLSnowIsland extends BiomeConfigHLBase
{
    public BiomeConfigHLSnowIsland()
    {
        super();
        
        this.biomeSlug = "snowisland";
    }
}
