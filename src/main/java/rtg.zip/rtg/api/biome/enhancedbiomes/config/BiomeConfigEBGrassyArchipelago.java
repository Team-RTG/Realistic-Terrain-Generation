package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBGrassyArchipelago extends BiomeConfigEBBase
{
    public BiomeConfigEBGrassyArchipelago()
    {
        super();
        
        this.biomeSlug = "grassyarchipelago";
    }
}
