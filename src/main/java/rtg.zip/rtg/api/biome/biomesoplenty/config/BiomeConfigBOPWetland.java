package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPWetland extends BiomeConfigBOPBase
{
    public BiomeConfigBOPWetland()
    {
        super();
        
        this.biomeSlug = "wetland";
    }
}
