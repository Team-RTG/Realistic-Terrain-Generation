package rtg.api.biome.highlands.config;


public class BiomeConfigHLSavannah extends BiomeConfigHLBase
{
    public BiomeConfigHLSavannah()
    {
        super();
        
        this.biomeSlug = "savannah";
    }
}
