package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaSavannaM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaSavannaM()
    {
        super();
        
        this.biomeSlug = "savannam";
    }
}
