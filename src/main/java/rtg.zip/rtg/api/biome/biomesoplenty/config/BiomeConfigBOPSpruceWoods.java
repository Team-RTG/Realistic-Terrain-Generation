package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPSpruceWoods extends BiomeConfigBOPBase
{
    public BiomeConfigBOPSpruceWoods()
    {
        super();
        
        this.biomeSlug = "sprucewoods";
    }
}
