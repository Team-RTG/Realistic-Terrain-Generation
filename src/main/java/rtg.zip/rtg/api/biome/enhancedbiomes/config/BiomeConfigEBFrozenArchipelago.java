package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBFrozenArchipelago extends BiomeConfigEBBase
{
    public BiomeConfigEBFrozenArchipelago()
    {
        super();
        
        this.biomeSlug = "frozenarchipelago";
    }
}
