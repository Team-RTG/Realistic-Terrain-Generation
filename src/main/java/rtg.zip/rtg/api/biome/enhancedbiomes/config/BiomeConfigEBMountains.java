package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBMountains extends BiomeConfigEBBase
{
    public BiomeConfigEBMountains()
    {
        super();
        
        this.biomeSlug = "mountains";
    }
}
