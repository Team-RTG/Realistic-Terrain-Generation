package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaSavanna extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaSavanna()
    {
        super();
        
        this.biomeSlug = "savanna";
    }
}
