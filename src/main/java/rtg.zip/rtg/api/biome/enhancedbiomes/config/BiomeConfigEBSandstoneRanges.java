package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSandstoneRanges extends BiomeConfigEBBase
{
    public BiomeConfigEBSandstoneRanges()
    {
        super();
        
        this.biomeSlug = "sandstoneranges";
    }
}
