package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaBirchForestHills extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaBirchForestHills()
    {
        super();
        
        this.biomeSlug = "birchforesthills";
    }
}
