package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBTropicalArchipelago extends BiomeConfigEBBase
{
    public BiomeConfigEBTropicalArchipelago()
    {
        super();
        
        this.biomeSlug = "tropicalarchipelago";
    }
}
