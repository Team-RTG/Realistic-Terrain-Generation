package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBForestedArchipelago extends BiomeConfigEBBase
{
    public BiomeConfigEBForestedArchipelago()
    {
        super();
        
        this.biomeSlug = "forestedarchipelago";
    }
}
