package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBFirForest extends BiomeConfigEBBase
{
    public BiomeConfigEBFirForest()
    {
        super();
        
        this.biomeSlug = "firforest";
    }
}
