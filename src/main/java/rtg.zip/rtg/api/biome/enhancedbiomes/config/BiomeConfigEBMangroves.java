package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBMangroves extends BiomeConfigEBBase
{
    public BiomeConfigEBMangroves()
    {
        super();
        
        this.biomeSlug = "mangroves";
    }
}
