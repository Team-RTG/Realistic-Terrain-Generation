package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBRedDesert extends BiomeConfigEBBase
{
    public BiomeConfigEBRedDesert()
    {
        super();
        
        this.biomeSlug = "reddesert";
    }
}
