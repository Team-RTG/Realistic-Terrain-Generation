package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaFrozenRiver extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaFrozenRiver()
    {
        super();
        
        this.biomeSlug = "frozenriver";
    }
}
