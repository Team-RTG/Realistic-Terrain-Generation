package rtg.api.biome.highlands.config;


public class BiomeConfigHLLowlands extends BiomeConfigHLBase
{
    public BiomeConfigHLLowlands()
    {
        super();
        
        this.biomeSlug = "lowlands";
    }
}
