package rtg.api.biome.highlands.config;


public class BiomeConfigHLTropicalIslands extends BiomeConfigHLBase
{
    public BiomeConfigHLTropicalIslands()
    {
        super();
        
        this.biomeSlug = "tropicalislands";
    }
}
