package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSnowyRanges extends BiomeConfigEBBase
{
    public BiomeConfigEBSnowyRanges()
    {
        super();
        
        this.biomeSlug = "snowyranges";
    }
}
