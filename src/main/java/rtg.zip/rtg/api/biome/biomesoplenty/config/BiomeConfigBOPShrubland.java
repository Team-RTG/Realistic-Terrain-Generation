package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPShrubland extends BiomeConfigBOPBase
{
    public BiomeConfigBOPShrubland()
    {
        super();
        
        this.biomeSlug = "shrubland";
    }
}
