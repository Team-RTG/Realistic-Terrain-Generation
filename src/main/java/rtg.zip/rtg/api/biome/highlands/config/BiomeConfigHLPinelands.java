package rtg.api.biome.highlands.config;


public class BiomeConfigHLPinelands extends BiomeConfigHLBase
{
    public BiomeConfigHLPinelands()
    {
        super();
        
        this.biomeSlug = "pinelands";
    }
}
