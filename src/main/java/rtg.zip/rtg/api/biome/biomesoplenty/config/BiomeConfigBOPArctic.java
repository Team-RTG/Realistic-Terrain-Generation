package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPArctic extends BiomeConfigBOPBase
{
    public BiomeConfigBOPArctic()
    {
        super();
        
        this.biomeSlug = "arctic";
    }
}
