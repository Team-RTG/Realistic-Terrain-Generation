package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaForest extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaForest()
    {
        super();
        
        this.biomeSlug = "forest";
    }
}
