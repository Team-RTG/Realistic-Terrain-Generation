package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaDesertHills extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaDesertHills()
    {
        super();
        
        this.biomeSlug = "deserthills";
    }
}
