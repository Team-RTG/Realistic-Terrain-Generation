package rtg.api.biome.thaumcraft.config;


public class BiomeConfigTCMagicalForest extends BiomeConfigTCBase
{
    public BiomeConfigTCMagicalForest()
    {
        super();
        
        this.biomeSlug = "magicalforest";
    }
}
