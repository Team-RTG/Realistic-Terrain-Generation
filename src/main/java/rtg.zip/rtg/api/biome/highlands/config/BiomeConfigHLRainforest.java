package rtg.api.biome.highlands.config;


public class BiomeConfigHLRainforest extends BiomeConfigHLBase
{
    public BiomeConfigHLRainforest()
    {
        super();
        
        this.biomeSlug = "rainforest";
    }
}
