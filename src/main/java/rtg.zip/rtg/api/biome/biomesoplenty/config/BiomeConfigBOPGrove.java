package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPGrove extends BiomeConfigBOPBase
{
    public BiomeConfigBOPGrove()
    {
        super();
        
        this.biomeSlug = "grove";
    }
}
