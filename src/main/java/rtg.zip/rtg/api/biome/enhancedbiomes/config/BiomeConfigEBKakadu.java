package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBKakadu extends BiomeConfigEBBase
{
    public BiomeConfigEBKakadu()
    {
        super();
        
        this.biomeSlug = "kakadu";
    }
}
