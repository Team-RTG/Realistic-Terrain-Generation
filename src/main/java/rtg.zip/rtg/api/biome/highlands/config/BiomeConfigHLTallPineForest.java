package rtg.api.biome.highlands.config;


public class BiomeConfigHLTallPineForest extends BiomeConfigHLBase
{
    public BiomeConfigHLTallPineForest()
    {
        super();
        
        this.biomeSlug = "tallpineforest";
    }
}
