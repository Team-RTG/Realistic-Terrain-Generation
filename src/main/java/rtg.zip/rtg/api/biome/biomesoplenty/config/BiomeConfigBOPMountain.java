package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPMountain extends BiomeConfigBOPBase
{
    public BiomeConfigBOPMountain()
    {
        super();
        
        this.biomeSlug = "mountain";
    }
}
