package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBCreekBed extends BiomeConfigEBBase
{
    public BiomeConfigEBCreekBed()
    {
        super();
        
        this.biomeSlug = "creekbed";
    }
}
