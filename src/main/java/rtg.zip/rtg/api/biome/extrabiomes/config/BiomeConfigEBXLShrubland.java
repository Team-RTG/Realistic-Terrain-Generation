package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLShrubland extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLShrubland()
    {
        super();
        
        this.biomeSlug = "shrubland";
    }
}
