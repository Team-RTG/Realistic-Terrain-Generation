package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPLushDesert extends BiomeConfigBOPBase
{
    public BiomeConfigBOPLushDesert()
    {
        super();
        
        this.biomeSlug = "lushdesert";
    }
}
