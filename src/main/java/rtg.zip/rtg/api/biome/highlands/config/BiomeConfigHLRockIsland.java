package rtg.api.biome.highlands.config;


public class BiomeConfigHLRockIsland extends BiomeConfigHLBase
{
    public BiomeConfigHLRockIsland()
    {
        super();
        
        this.biomeSlug = "rockisland";
    }
}
