package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPGarden extends BiomeConfigBOPBase
{
    public BiomeConfigBOPGarden()
    {
        super();
        
        this.biomeSlug = "garden";
    }
}
