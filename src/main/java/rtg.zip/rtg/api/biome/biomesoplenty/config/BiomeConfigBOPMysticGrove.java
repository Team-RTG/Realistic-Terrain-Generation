package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPMysticGrove extends BiomeConfigBOPBase
{
    public BiomeConfigBOPMysticGrove()
    {
        super();
        
        this.biomeSlug = "mysticgrove";
    }
}
