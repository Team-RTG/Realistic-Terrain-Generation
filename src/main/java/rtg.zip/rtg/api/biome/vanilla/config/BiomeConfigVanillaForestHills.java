package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaForestHills extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaForestHills()
    {
        super();
        
        this.biomeSlug = "foresthills";
    }
}
