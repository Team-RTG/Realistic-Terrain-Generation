package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaOcean extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaOcean()
    {
        super();
        
        this.biomeSlug = "ocean";
    }
}
