package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaSwamplandM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaSwamplandM()
    {
        super();
        
        this.biomeSlug = "swamplandm";
    }
}
