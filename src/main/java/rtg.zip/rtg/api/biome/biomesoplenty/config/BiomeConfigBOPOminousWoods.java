package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPOminousWoods extends BiomeConfigBOPBase
{
    public BiomeConfigBOPOminousWoods()
    {
        super();
        
        this.biomeSlug = "ominouswoods";
    }
}
