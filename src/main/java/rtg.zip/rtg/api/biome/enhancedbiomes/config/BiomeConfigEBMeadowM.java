package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBMeadowM extends BiomeConfigEBBase
{
    public BiomeConfigEBMeadowM()
    {
        super();
        
        this.biomeSlug = "meadowm";
    }
}
