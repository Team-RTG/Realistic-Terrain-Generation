package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPSilkglades extends BiomeConfigBOPBase
{
    public BiomeConfigBOPSilkglades()
    {
        super();
        
        this.biomeSlug = "silkglades";
    }
}
