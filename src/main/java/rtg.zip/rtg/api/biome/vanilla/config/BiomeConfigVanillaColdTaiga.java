package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaColdTaiga extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaColdTaiga()
    {
        super();
        
        this.biomeSlug = "coldtaiga";
    }
}
