package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBCarr extends BiomeConfigEBBase
{
    public BiomeConfigEBCarr()
    {
        super();
        
        this.biomeSlug = "carr";
    }
}
