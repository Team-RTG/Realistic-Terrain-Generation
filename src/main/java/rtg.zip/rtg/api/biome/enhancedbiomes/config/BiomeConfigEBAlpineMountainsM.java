package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBAlpineMountainsM extends BiomeConfigEBBase
{
    public BiomeConfigEBAlpineMountainsM()
    {
        super();
        
        this.biomeSlug = "alpinemountainsm";
    }
}
