package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBColdFirForest extends BiomeConfigEBBase
{
    public BiomeConfigEBColdFirForest()
    {
        super();
        
        this.biomeSlug = "coldfirforest";
    }
}
