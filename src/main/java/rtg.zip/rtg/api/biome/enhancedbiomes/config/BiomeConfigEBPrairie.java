package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBPrairie extends BiomeConfigEBBase
{
    public BiomeConfigEBPrairie()
    {
        super();
        
        this.biomeSlug = "prairie";
    }
}
