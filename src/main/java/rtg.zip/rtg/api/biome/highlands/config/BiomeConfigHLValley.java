package rtg.api.biome.highlands.config;


public class BiomeConfigHLValley extends BiomeConfigHLBase
{
    public BiomeConfigHLValley()
    {
        super();
        
        this.biomeSlug = "valley";
    }
}
