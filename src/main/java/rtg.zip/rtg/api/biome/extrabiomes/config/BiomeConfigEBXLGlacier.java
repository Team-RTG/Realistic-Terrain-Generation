package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLGlacier extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLGlacier()
    {
        super();
        
        this.biomeSlug = "glacier";
    }
}
