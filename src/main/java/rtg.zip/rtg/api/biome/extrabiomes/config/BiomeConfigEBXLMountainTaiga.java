package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLMountainTaiga extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLMountainTaiga()
    {
        super();
        
        this.biomeSlug = "mountaintaiga";
    }
}
