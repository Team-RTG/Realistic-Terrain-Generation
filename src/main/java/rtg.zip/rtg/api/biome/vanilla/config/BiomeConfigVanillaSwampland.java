package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaSwampland extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaSwampland()
    {
        super();
        
        this.biomeSlug = "swampland";
    }
}
