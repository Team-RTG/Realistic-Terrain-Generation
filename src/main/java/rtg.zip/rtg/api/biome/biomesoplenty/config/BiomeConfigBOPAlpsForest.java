package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPAlpsForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPAlpsForest()
    {
        super();
        
        this.biomeSlug = "alpsforest";
    }
}
