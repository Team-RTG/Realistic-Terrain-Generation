package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaIceMountains extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaIceMountains()
    {
        super();
        
        this.biomeSlug = "icemountains";
    }
}
