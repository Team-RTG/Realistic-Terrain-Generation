package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLForestedIsland extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLForestedIsland()
    {
        super();
        
        this.biomeSlug = "forestedisland";
    }
}
