package rtg.api.biome.highlands.config;


public class BiomeConfigHLOutback extends BiomeConfigHLBase
{
    public BiomeConfigHLOutback()
    {
        super();
        
        this.biomeSlug = "outback";
    }
}
