package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPAlps extends BiomeConfigBOPBase
{
    public BiomeConfigBOPAlps()
    {
        super();
        
        this.biomeSlug = "alps";
    }
}
