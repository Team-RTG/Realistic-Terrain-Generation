package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBFloweryArchipelago extends BiomeConfigEBBase
{
    public BiomeConfigEBFloweryArchipelago()
    {
        super();
        
        this.biomeSlug = "floweryarchipelago";
    }
}
