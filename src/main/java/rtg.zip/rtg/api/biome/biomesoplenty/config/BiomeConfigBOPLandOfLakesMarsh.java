package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPLandOfLakesMarsh extends BiomeConfigBOPBase
{
    public BiomeConfigBOPLandOfLakesMarsh()
    {
        super();
        
        this.biomeSlug = "landoflakesmarsh";
    }
}
