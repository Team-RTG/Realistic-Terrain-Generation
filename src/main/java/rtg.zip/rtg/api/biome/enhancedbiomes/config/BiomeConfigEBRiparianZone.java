package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBRiparianZone extends BiomeConfigEBBase
{
    public BiomeConfigEBRiparianZone()
    {
        super();
        
        this.biomeSlug = "riparianzone";
    }
}
