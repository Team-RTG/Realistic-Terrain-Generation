package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaRedwoodTaigaHills extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaRedwoodTaigaHills()
    {
        super();
        
        this.biomeSlug = "redwoodtaigahills";
    }
}
