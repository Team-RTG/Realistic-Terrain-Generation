package rtg.api.biome.highlands.config;


public class BiomeConfigHLDunes extends BiomeConfigHLBase
{
    public BiomeConfigHLDunes()
    {
        super();
        
        this.biomeSlug = "dunes";
    }
}
