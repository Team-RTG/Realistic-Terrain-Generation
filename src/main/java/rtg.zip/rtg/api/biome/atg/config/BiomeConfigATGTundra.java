package rtg.api.biome.atg.config;


public class BiomeConfigATGTundra extends BiomeConfigATGBase
{
    public BiomeConfigATGTundra()
    {
        super();
        
        this.biomeSlug = "tundra";
    }
}
