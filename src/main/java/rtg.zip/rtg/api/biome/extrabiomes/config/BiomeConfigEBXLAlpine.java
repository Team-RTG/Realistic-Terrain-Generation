package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLAlpine extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLAlpine()
    {
        super();
        
        this.biomeSlug = "alpine";
    }
}
