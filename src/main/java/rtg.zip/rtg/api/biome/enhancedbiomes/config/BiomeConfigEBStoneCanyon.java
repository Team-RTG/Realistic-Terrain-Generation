package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBStoneCanyon extends BiomeConfigEBBase
{
    public BiomeConfigEBStoneCanyon()
    {
        super();
        
        this.biomeSlug = "stonecanyon";
    }
}
