package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBAspenHills extends BiomeConfigEBBase
{
    public BiomeConfigEBAspenHills()
    {
        super();
        
        this.biomeSlug = "aspenhills";
    }
}
