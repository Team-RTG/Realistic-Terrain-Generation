package rtg.api.biome.arsmagica.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigAMBase extends BiomeConfig
{

    public BiomeConfigAMBase()
    {
        super();
        
        this.modSlug = "arsmagica";
    }
}
