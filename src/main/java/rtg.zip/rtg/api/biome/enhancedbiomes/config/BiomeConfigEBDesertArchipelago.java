package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBDesertArchipelago extends BiomeConfigEBBase
{
    public BiomeConfigEBDesertArchipelago()
    {
        super();
        
        this.biomeSlug = "desertarchipelago";
    }
}
