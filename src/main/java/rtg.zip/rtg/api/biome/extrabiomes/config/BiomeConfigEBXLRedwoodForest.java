package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLRedwoodForest extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLRedwoodForest()
    {
        super();
        
        this.biomeSlug = "redwoodforest";
    }
}
