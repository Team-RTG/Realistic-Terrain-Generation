package rtg.api.biome.highlands.config;


public class BiomeConfigHLMeadow extends BiomeConfigHLBase
{
    public BiomeConfigHLMeadow()
    {
        super();
        
        this.biomeSlug = "meadow";
    }
}
