package rtg.api.biome.thaumcraft.config;


public class BiomeConfigTCEerie extends BiomeConfigTCBase
{
    public BiomeConfigTCEerie()
    {
        super();
        
        this.biomeSlug = "eerie";
    }
}
