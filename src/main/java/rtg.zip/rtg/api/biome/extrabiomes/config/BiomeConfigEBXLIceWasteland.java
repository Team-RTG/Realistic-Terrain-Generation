package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLIceWasteland extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLIceWasteland()
    {
        super();
        
        this.biomeSlug = "icewasteland";
    }
}
