package rtg.api.biome.highlands.config;


public class BiomeConfigHLRedwoodForest extends BiomeConfigHLBase
{
    public BiomeConfigHLRedwoodForest()
    {
        super();
        
        this.biomeSlug = "redwoodforest";
    }
}
