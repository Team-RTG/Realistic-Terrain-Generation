package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaColdTaigaM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaColdTaigaM()
    {
        super();
        
        this.biomeSlug = "coldtaigam";
    }
}
