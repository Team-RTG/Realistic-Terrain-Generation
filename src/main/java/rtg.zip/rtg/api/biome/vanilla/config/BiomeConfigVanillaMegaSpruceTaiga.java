package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMegaSpruceTaiga extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMegaSpruceTaiga()
    {
        super();
        
        this.biomeSlug = "megasprucetaiga";
    }
}
