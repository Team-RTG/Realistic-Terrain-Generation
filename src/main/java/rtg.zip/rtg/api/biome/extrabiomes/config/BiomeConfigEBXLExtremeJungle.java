package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLExtremeJungle extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLExtremeJungle()
    {
        super();
        
        this.biomeSlug = "extremejungle";
    }
}
