package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaExtremeHillsEdge extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaExtremeHillsEdge()
    {
        super();
        
        this.biomeSlug = "extremehillsedge";
    }
}
