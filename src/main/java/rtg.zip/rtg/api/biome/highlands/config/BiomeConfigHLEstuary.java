package rtg.api.biome.highlands.config;


public class BiomeConfigHLEstuary extends BiomeConfigHLBase
{
    public BiomeConfigHLEstuary()
    {
        super();
        
        this.biomeSlug = "estuary";
    }
}
