package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBPineForest extends BiomeConfigEBBase
{
    public BiomeConfigEBPineForest()
    {
        super();
        
        this.biomeSlug = "pineforest";
    }
}
