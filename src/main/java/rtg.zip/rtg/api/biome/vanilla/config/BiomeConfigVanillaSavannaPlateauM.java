package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaSavannaPlateauM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaSavannaPlateauM()
    {
        super();
        
        this.biomeSlug = "savannaplateaum";
    }
}
