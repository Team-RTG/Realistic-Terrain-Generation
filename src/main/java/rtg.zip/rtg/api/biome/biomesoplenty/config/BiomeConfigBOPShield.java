package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPShield extends BiomeConfigBOPBase
{
    public BiomeConfigBOPShield()
    {
        super();
        
        this.biomeSlug = "shield";
    }
}
