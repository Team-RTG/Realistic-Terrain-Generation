package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPSeasonalForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPSeasonalForest()
    {
        super();
        
        this.biomeSlug = "seasonalforest";
    }
}
