package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLSnowyRainforest extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLSnowyRainforest()
    {
        super();
        
        this.biomeSlug = "snowyrainforest";
    }
}
