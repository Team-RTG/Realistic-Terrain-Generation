package rtg.api.biome.highlands.config;


public class BiomeConfigHLBaldHill extends BiomeConfigHLBase
{
    public BiomeConfigHLBaldHill()
    {
        super();
        
        this.biomeSlug = "baldhill";
    }
}
