package rtg.api.biome.highlands.config;


public class BiomeConfigHLBadlands extends BiomeConfigHLBase
{
    public BiomeConfigHLBadlands()
    {
        super();
        
        this.biomeSlug = "badlands";
    }
}
