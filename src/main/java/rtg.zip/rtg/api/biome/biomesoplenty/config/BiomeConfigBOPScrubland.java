package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPScrubland extends BiomeConfigBOPBase
{
    public BiomeConfigBOPScrubland()
    {
        super();
        
        this.biomeSlug = "scrubland";
    }
}
