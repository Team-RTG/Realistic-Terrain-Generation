package rtg.api.biome.atg.config;


public class BiomeConfigATGVolcano extends BiomeConfigATGBase
{
    public BiomeConfigATGVolcano()
    {
        super();
        
        this.biomeSlug = "volcano";
    }
}
