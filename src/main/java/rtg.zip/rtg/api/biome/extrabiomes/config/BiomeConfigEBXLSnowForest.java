package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLSnowForest extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLSnowForest()
    {
        super();
        
        this.biomeSlug = "snowforest";
    }
}
