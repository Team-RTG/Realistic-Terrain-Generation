package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMesaPlateauFM extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMesaPlateauFM()
    {
        super();
        
        this.biomeSlug = "mesaplateaufm";
    }
}
