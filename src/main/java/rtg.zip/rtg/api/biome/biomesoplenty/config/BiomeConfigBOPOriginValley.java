package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPOriginValley extends BiomeConfigBOPBase
{
    public BiomeConfigBOPOriginValley()
    {
        super();
        
        this.biomeSlug = "originvalley";
    }
}
