package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPConiferousForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPConiferousForest()
    {
        super();
        
        this.biomeSlug = "coniferousforest";
    }
}
