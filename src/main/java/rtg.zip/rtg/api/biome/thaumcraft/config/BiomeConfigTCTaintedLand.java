package rtg.api.biome.thaumcraft.config;


public class BiomeConfigTCTaintedLand extends BiomeConfigTCBase
{
    public BiomeConfigTCTaintedLand()
    {
        super();
        
        this.biomeSlug = "taintedland";
    }
}
