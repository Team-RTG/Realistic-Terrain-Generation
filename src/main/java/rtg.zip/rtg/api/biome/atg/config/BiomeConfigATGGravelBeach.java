package rtg.api.biome.atg.config;


public class BiomeConfigATGGravelBeach extends BiomeConfigATGBase
{
    public BiomeConfigATGGravelBeach()
    {
        super();
        
        this.biomeSlug = "gravelbeach";
    }
}
