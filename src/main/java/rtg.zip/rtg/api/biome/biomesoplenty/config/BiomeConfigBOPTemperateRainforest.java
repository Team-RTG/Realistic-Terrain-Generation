package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPTemperateRainforest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPTemperateRainforest()
    {
        super();
        
        this.biomeSlug = "temperaterainforest";
    }
}
