package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPBog extends BiomeConfigBOPBase
{
    public BiomeConfigBOPBog()
    {
        super();
        
        this.biomeSlug = "bog";
    }
}
