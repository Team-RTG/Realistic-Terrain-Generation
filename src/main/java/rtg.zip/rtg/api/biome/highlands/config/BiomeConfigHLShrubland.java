package rtg.api.biome.highlands.config;


public class BiomeConfigHLShrubland extends BiomeConfigHLBase
{
    public BiomeConfigHLShrubland()
    {
        super();
        
        this.biomeSlug = "shrubland";
    }
}
