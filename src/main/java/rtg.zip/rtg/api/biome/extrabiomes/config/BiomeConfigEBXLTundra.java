package rtg.api.biome.extrabiomes.config;


public class BiomeConfigEBXLTundra extends BiomeConfigEBXLBase
{
    public BiomeConfigEBXLTundra()
    {
        super();
        
        this.biomeSlug = "tundra";
    }
}
