package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSandstoneCanyon2 extends BiomeConfigEBBase
{
    public BiomeConfigEBSandstoneCanyon2()
    {
        super();
        
        this.biomeSlug = "sandstonecanyon2";
    }
}
