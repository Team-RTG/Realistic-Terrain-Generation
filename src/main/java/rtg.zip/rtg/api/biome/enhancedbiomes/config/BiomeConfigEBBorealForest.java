package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBBorealForest extends BiomeConfigEBBase
{
    public BiomeConfigEBBorealForest()
    {
        super();
        
        this.biomeSlug = "borealforest";
    }
}
