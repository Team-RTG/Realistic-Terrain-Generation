package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPCrag extends BiomeConfigBOPBase
{
    public BiomeConfigBOPCrag()
    {
        super();
        
        this.biomeSlug = "crag";
    }
}
