package rtg.api.biome.highlands.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigHL
{
    public static BiomeConfigHLAlps biomeConfigHLAlps;
    public static BiomeConfigHLAutumnForest biomeConfigHLAutumnForest;
    public static BiomeConfigHLBadlands biomeConfigHLBadlands;
    public static BiomeConfigHLBaldHill biomeConfigHLBaldHill;
    public static BiomeConfigHLBirchHills biomeConfigHLBirchHills;
    public static BiomeConfigHLBog biomeConfigHLBog;
    public static BiomeConfigHLCanyon biomeConfigHLCanyon;
    public static BiomeConfigHLCliffs biomeConfigHLCliffs;
    public static BiomeConfigHLDesertIsland biomeConfigHLDesertIsland;
    public static BiomeConfigHLDesertMountains biomeConfigHLDesertMountains;
    public static BiomeConfigHLDunes biomeConfigHLDunes;
    public static BiomeConfigHLEstuary biomeConfigHLEstuary;
    public static BiomeConfigHLFlyingMountains biomeConfigHLFlyingMountains;
    public static BiomeConfigHLForestIsland biomeConfigHLForestIsland;
    public static BiomeConfigHLGlacier biomeConfigHLGlacier;
    public static BiomeConfigHLHighlandsB biomeConfigHLHighlandsB;
    public static BiomeConfigHLJungleIsland biomeConfigHLJungleIsland;
    public static BiomeConfigHLLake biomeConfigHLLake;
    public static BiomeConfigHLLowlands biomeConfigHLLowlands;
    public static BiomeConfigHLMeadow biomeConfigHLMeadow;
    public static BiomeConfigHLMesa biomeConfigHLMesa;
    public static BiomeConfigHLOasis biomeConfigHLOasis;
    public static BiomeConfigHLOutback biomeConfigHLOutback;
    public static BiomeConfigHLPinelands biomeConfigHLPinelands;
    public static BiomeConfigHLRainforest biomeConfigHLRainforest;
    public static BiomeConfigHLRedwoodForest biomeConfigHLRedwoodForest;
    public static BiomeConfigHLRockIsland biomeConfigHLRockIsland;
    public static BiomeConfigHLRockMountains biomeConfigHLRockMountains;
    public static BiomeConfigHLSahel biomeConfigHLSahel;
    public static BiomeConfigHLSavannah biomeConfigHLSavannah;
    public static BiomeConfigHLShrubland biomeConfigHLShrubland;
    public static BiomeConfigHLSnowIsland biomeConfigHLSnowIsland;
    public static BiomeConfigHLSnowMountains biomeConfigHLSnowMountains;
    public static BiomeConfigHLSteppe biomeConfigHLSteppe;
    public static BiomeConfigHLTallPineForest biomeConfigHLTallPineForest;
    public static BiomeConfigHLTropicalIslands biomeConfigHLTropicalIslands;
    public static BiomeConfigHLTropics biomeConfigHLTropics;
    public static BiomeConfigHLTundra biomeConfigHLTundra;
    public static BiomeConfigHLValley biomeConfigHLValley;
    public static BiomeConfigHLVolcanoIsland biomeConfigHLVolcanoIsland;
    public static BiomeConfigHLWindyIsland biomeConfigHLWindyIsland;
    public static BiomeConfigHLWoodlands biomeConfigHLWoodlands;
    public static BiomeConfigHLWoodsMountains biomeConfigHLWoodsMountains;
    
    public static BiomeConfig[] getBiomeConfigs()
    {
        BiomeConfig[] biomeConfigs = new BiomeConfig[]{
            biomeConfigHLAlps,
            biomeConfigHLAutumnForest,
            biomeConfigHLBadlands,
            biomeConfigHLBaldHill,
            biomeConfigHLBirchHills,
            biomeConfigHLBog,
            biomeConfigHLCanyon,
            biomeConfigHLCliffs,
            biomeConfigHLDesertIsland,
            biomeConfigHLDesertMountains,
            biomeConfigHLDunes,
            biomeConfigHLEstuary,
            biomeConfigHLFlyingMountains,
            biomeConfigHLForestIsland,
            biomeConfigHLGlacier,
            biomeConfigHLHighlandsB,
            biomeConfigHLJungleIsland,
            biomeConfigHLLake,
            biomeConfigHLLowlands,
            biomeConfigHLMeadow,
            biomeConfigHLMesa,
            biomeConfigHLOasis,
            biomeConfigHLOutback,
            biomeConfigHLPinelands,
            biomeConfigHLRainforest,
            biomeConfigHLRedwoodForest,
            biomeConfigHLRockIsland,
            biomeConfigHLRockMountains,
            biomeConfigHLSahel,
            biomeConfigHLSavannah,
            biomeConfigHLShrubland,
            biomeConfigHLSnowIsland,
            biomeConfigHLSnowMountains,
            biomeConfigHLSteppe,
            biomeConfigHLTallPineForest,
            biomeConfigHLTropicalIslands,
            biomeConfigHLTropics,
            biomeConfigHLTundra,
            biomeConfigHLValley,
            biomeConfigHLVolcanoIsland,
            biomeConfigHLWindyIsland,
            biomeConfigHLWoodlands,
            biomeConfigHLWoodsMountains
        };
        
        return biomeConfigs;
    }
}
