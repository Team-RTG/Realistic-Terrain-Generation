package rtg.api.biome.enhancedbiomes.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigEBBase extends BiomeConfig
{
    public BiomeConfigEBBase()
    {
        super();
        
        this.modSlug = "enhancedbiomes";
    }
}
