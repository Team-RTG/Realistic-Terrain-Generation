package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBSilverPineForest extends BiomeConfigEBBase
{
    public BiomeConfigEBSilverPineForest()
    {
        super();
        
        this.biomeSlug = "silverpineforest";
    }
}
