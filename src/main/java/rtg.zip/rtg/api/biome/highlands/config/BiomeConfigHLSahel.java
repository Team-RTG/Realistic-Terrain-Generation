package rtg.api.biome.highlands.config;


public class BiomeConfigHLSahel extends BiomeConfigHLBase
{
    public BiomeConfigHLSahel()
    {
        super();
        
        this.biomeSlug = "sahel";
    }
}
