package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPCoralReef extends BiomeConfigBOPBase
{
    public BiomeConfigBOPCoralReef()
    {
        super();
        
        this.biomeSlug = "coralreef";
    }
}
