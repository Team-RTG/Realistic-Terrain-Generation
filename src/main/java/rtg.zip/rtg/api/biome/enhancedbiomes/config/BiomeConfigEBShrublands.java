package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBShrublands extends BiomeConfigEBBase
{
    public BiomeConfigEBShrublands()
    {
        super();
        
        this.biomeSlug = "shrublands";
    }
}
