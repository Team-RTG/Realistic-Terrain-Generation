package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaMushroomIsland extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaMushroomIsland()
    {
        super();
        
        this.biomeSlug = "mushroomisland";
    }
}
