package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaJungle extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaJungle()
    {
        super();
        
        this.biomeSlug = "jungle";
    }
}
