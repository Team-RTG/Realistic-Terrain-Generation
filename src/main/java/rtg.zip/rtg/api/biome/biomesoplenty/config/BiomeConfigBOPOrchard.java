package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPOrchard extends BiomeConfigBOPBase
{
    public BiomeConfigBOPOrchard()
    {
        super();
        
        this.biomeSlug = "orchard";
    }
}
