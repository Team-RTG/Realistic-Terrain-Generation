package rtg.api.biome.biomesoplenty.config;

import rtg.api.biome.BiomeConfig;

public class BiomeConfigBOPBase extends BiomeConfig
{
    public BiomeConfigBOPBase()
    {
        super();
        
        this.modSlug = "biomesoplenty";
    }
}
