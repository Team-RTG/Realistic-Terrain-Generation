package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPMangrove extends BiomeConfigBOPBase
{
    public BiomeConfigBOPMangrove()
    {
        super();
        
        this.biomeSlug = "mangrove";
    }
}
