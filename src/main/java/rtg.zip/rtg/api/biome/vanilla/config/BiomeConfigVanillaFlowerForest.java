package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaFlowerForest extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaFlowerForest()
    {
        super();
        
        this.biomeSlug = "flowerforest";
    }
}
