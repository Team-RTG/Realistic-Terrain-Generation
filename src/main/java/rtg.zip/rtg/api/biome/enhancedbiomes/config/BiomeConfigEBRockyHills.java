package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBRockyHills extends BiomeConfigEBBase
{
    public BiomeConfigEBRockyHills()
    {
        super();
        
        this.biomeSlug = "rockyhills";
    }
}
