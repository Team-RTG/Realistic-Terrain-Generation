package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPRainforest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPRainforest()
    {
        super();
        
        this.biomeSlug = "rainforest";
    }
}
