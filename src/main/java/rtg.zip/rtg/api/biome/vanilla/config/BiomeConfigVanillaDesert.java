package rtg.api.biome.vanilla.config;


public class BiomeConfigVanillaDesert extends BiomeConfigVanillaBase
{
    public BiomeConfigVanillaDesert()
    {
        super();
        
        this.biomeSlug = "desert";
    }
}
