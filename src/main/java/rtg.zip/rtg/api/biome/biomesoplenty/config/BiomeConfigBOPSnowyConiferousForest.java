package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPSnowyConiferousForest extends BiomeConfigBOPBase
{
    public BiomeConfigBOPSnowyConiferousForest()
    {
        super();
        
        this.biomeSlug = "snowyconiferousforest";
    }
}
