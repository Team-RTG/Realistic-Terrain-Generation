package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBRainforest extends BiomeConfigEBBase
{
    public BiomeConfigEBRainforest()
    {
        super();
        
        this.biomeSlug = "rainforest";
    }
}
