package rtg.api.biome.biomesoplenty.config;



public class BiomeConfigBOPBayou extends BiomeConfigBOPBase
{
    public BiomeConfigBOPBayou()
    {
        super();
        
        this.biomeSlug = "bayou";
    }
}
