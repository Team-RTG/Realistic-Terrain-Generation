package rtg.api.biome.enhancedbiomes.config;

public class BiomeConfigEBOakForest extends BiomeConfigEBBase
{
    public BiomeConfigEBOakForest()
    {
        super();
        
        this.biomeSlug = "oakforest";
    }
}
